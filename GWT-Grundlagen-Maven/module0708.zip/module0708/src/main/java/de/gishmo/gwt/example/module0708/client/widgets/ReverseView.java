package de.gishmo.gwt.example.module0708.client.widgets;

public interface ReverseView<T> {

  T getPresenter();

  void setPresenter(T presenter);

}
