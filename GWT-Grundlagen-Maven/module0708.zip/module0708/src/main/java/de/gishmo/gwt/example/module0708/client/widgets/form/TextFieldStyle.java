package de.gishmo.gwt.example.module0708.client.widgets.form;

import com.google.gwt.resources.client.CssResource;

public interface TextFieldStyle
  extends CssResource {

  String panel();

  String label();

  String textBox();

  String widgetPanel();

}
