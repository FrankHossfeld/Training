package de.gishmo.gwt.example.module0803.client.widgets;

public interface ReverseView<T> {

  public T getPresenter();
  
  public void setPresenter(T presenter);
  
}
