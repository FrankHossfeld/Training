package de.gishmo.gwt.example.module0803.client;

import com.google.gwt.core.client.EntryPoint;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class Module0804 implements EntryPoint {

  /**
   * 
   * This is the entry point method.
   */
  public void onModuleLoad() {
    Application application = new Application();
    application.run();
  }
}
