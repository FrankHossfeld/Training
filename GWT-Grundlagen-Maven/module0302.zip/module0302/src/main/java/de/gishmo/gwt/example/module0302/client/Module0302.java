package de.gishmo.gwt.example.module0302.client;

import com.google.gwt.core.client.EntryPoint;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class Module0302
  implements EntryPoint {
  /**
   * This is the entry point method.
   */
  public void onModuleLoad() {
  }
}
